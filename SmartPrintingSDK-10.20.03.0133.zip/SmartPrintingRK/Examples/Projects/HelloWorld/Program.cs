﻿using Honeywell.Printer;
using System;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            // Set up print control and drawing
            PrintControl printControl = new PrintControl();
            Drawing drawing = new Drawing();

            // Perform test feed
            State state = printControl.TestFeed();

            // Print Hello World (if testfeed was OK)
            if (state == State.NoError)
            {
                Drawing.Text text = new Drawing.Text();
                text.Point = new Point(100, 100);
                text.Data = "Hello World";
                text.Height = 36;

                drawing += text;
                drawing.PartialRendering = true;

                state = printControl.PrintFeed(drawing, 1);

                if (state != State.NoError)
                {
                    Console.WriteLine("PrintFeed failed: {0}", state.ToString());
                }
            }
            else
            {
                Console.WriteLine("TestFeed failed: {0}", state.ToString());
            }

            Console.WriteLine("Exit");
        }
    }
}
