using System;
using System.IO;

class TestConfiguration
{
    static int Main(string[] args)
    {
        Console.WriteLine("Configuration");

        // Init new Configuration
        Configuration configuration = new Configuration();

        // Adjust settings
        string orgContact = 
					 configuration.GetParameter("System Settings,General,System Contact");
        configuration.SetParameter("System Settings,General,System Contact", 
																	 "TestConfiguration");
        string newContact = 
					 configuration.GetParameter("System Settings,General,System Contact");

        // Export all settings
        configuration.WriteFile("/tmp/allconfig.xml");

        // Import single parameter
        using (StreamWriter sw = File.CreateText("/tmp/singleparam.xml")) 
        {
            sw.WriteLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            sw.WriteLine("<DevInfo Action=\"Set\" SeqNo=\"2\">");
            sw.WriteLine("<Subsystem Name=\"Printer\" Version=\"1.0\">");
            sw.WriteLine("<Group Name=\"Printer Settings\">");
            sw.WriteLine("<Group Name=\"System Settings\">");
            sw.WriteLine("<Group Name=\"General\">");
            sw.WriteLine("<Field Name=\"System Contact\">" + orgContact + 
												 "</Field>");
            sw.WriteLine("</Group>");
            sw.WriteLine("</Group>");
            sw.WriteLine("</Group>");
            sw.WriteLine("</Subsystem>");
            sw.WriteLine("</DevInfo>");
        }	
        configuration.ReadFile("/tmp/singleparam.xml");
        string importedContact = 
					configuration.GetParameter("System Settings,General,System Contact");

				// Output result
        Console.WriteLine("Original contact: {0}", orgContact);
        Console.WriteLine("New      contact: {0}", newContact);
        Console.WriteLine("Imported contact: {0}", importedContact);

        // Delete temporary files
        File.Delete("/tmp/singleparam.xml");
        File.Delete("/tmp/allconfig.xml");

        // Cleanup Configuration
        configuration.Dispose();

        return 0;
    }
}
