using System;

class TestDrawing
{
	static int Main(string[] args)
	{
		Console.WriteLine("Drawing");
		
		// Init new PrintControl and Drawing
		PrintControl printControl = new PrintControl();
		Drawing drawing = new Drawing();
		
		// Render text on drawing
		drawing += new Drawing.Text(300, 300, "Univers", "HELLO WORLD");

		// Print label (1 copy)
		printControl.PrintFeed(drawing, 1);

		// Cleanup PrintControl and Drawing
		printControl.Dispose();
		drawing.Dispose();
		
		return 0;
	}	
}

