using Honeywell.Printer;
using System;

class TestRFID
{
	static int Main(string[] args)
	{
		Console.WriteLine("RFID");
		State rv;
		String rfidVer = String.Empty;

		// Init new PrintControl and Drawing
		PrintControl printControl = new PrintControl();
		Drawing drawing = new Drawing();

		// Render text on drawing
		drawing += new Drawing.Text(300, 300, "Univers", "HELLO WORLD");

		RFID rfid = new RFID();

		rv = rfid.GetFirmwareVersion(ref rfidVer);
		Console.WriteLine("RFID Firmware Version = {0}", rfidVer);

		// RFID TAGID
		rv = rfid.ID();
		if (rv == State.NoError)
		{
			string rfidtxt = "123456789ABC";
			// RFID Write
			rv = rfid.Write(RFID.FieldType.EPC, RFID.FormatType.HEX, 4, 12, rfidtxt);

		}

		// Print label (1 copy)
		printControl.PrintFeed(drawing, 1);

		// Cleanup PrintControl and Drawing
		printControl.Dispose();
		drawing.Dispose();

		return 0;
	}
}
