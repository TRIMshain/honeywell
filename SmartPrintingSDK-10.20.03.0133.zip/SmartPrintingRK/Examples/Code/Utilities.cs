using Honeywell.Printer;
using System;

class TestUtilities
{
    static int Main(string[] args)
    {
        Console.WriteLine("Utilities");

        // Init new Utilities
        Utilities utility = new Utilities();

        // Call a system command
        utility.CallSystemCmd("ls -al");

        // Cleanup Utilities
        utility.Dispose();

        return 0;
    }
}
