using System;
using System.IO;
using System.Threading;

class TestCommunicationBluetoothClient
{
    static int Main(string[] args)
    {
        Console.WriteLine("CommunicationBluetoothClient");

		// Set up a Bluetooth client
		Communication.BluetoothClient bluetoothClient
			= new Communication.BluetoothClient();
		
		// Discover devices forever, maximum 10 devices
		BluetoothDeviceInfo[] discoveredDevices = 
			bluetoothClient.DiscoverDevices(-1, 10);
		
		// Find the first keyboard device
		BluetoothDeviceInfo keyboardDevice = null;
		foreach (BluetoothDeviceInfo discoveredDevice in discoveredDevices)
		{
			Console.WriteLine("Discovered: {0}", discoveredDevice.DeviceName);
			if(discoveredDevice.DeviceName.IndexOf("Keyboard") != -1)
			{
				keyboardDevice = discoveredDevice;
			}
		}

		if(keyboardDevice != null)
		{
			// Connect to the device (without PIN)
			bluetoothClient.Connect(keyboardDevice);
			
			if(bluetoothClient.Connected)
			{
				Console.WriteLine("Connected to {0}", keyboardDevice.DeviceName);

				try
				{
					// Get stream to communicate with client
					FileStream fileStream = bluetoothClient.GetStream();

					int timeout = 0;
					int i = 0;
					while((timeout < 10) && bluetoothClient.Connected)
					{
						Console.WriteLine("Waiting for data. Exit in {0} secs",
						                  (10 - timeout));
					
						Byte[] bytes = new Byte[256];
						if((i = fileStream.Read(bytes, 0, bytes.Length)) > 0)
						{
							string data = System.Text.Encoding.ASCII.GetString(bytes, 0, i);
							Console.WriteLine("Read {0} bytes: {1}", data.Length, data);
							timeout = 0;
						}
						else 
						{
							Thread.Sleep(1000);
							timeout++;
						}
					}
			
					// Close stream
					fileStream.Close();
				}
				catch(Exception e)
				{
					Console.WriteLine("Exception: {0}", e.Message);
				}

				// Close connection 
				bluetoothClient.Close();
			}
			else
			{
				Console.WriteLine("Failed connect to {0}", keyboardDevice.DeviceName);
			}
		}
		else
		{
			Console.WriteLine("No Bluetooth keyboard discovered.");
		}

		bluetoothClient.Dispose();
		
		return 0;
	}
}

