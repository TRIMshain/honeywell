using System;
using System.Collections.Generic;

class TestUICanvasText
{
	static UI.Canvas canvas;
	static UI.Canvas.Timer timer;
	static UI.Canvas.Text timeText;

	static Color white = new Color(255, 255, 255, 255);
	static Color black = new Color(0, 0, 0, 255);
	static int duration = 0;	

	static int Main(string[] args)
	{
		Console.WriteLine("UICanvasText");
		
		// Init new UI canvas
		canvas = new UI.Canvas();
		
		// Add UI black background
		UI.Canvas.Rectangle bg = new UI.Canvas.Rectangle(0, 0, canvas.Width,
		                                                 canvas.Height, black);
		canvas += bg;
		
		// Add UI title text
		UI.Canvas.Text titleText = new UI.Canvas.Text(5, (canvas.Height / 3) - 20, 
																									"TestUICanvasText", 
																									"Univers", 18, white);
		canvas += titleText;
		
		// Add time text object
		timeText = new UI.Canvas.Text(5, (canvas.Height * 2 / 3) - 20, 
																	DateTime.Now.ToString("HH:mm:ss.fff"), 
																	"Univers", 18, white);
		canvas += timeText;

		// Set up timer event handler, update every 100 ms
		timer = new UI.Canvas.Timer();
		timer.Interval = 100;
		timer.Tick += new UI.Canvas.TimerEventHandler(UpdateText);
		timer.Start();
		
		// Enter UI main loop
		canvas.Run();
		
		// Cleanup UI
		canvas.Dispose();
		timer.Dispose();
		
		return 0;
	}
	
	public static void UpdateText(Object obj, UI.Canvas.TimerEventArgs eventArgs)
	{
		// Update time text object
		timeText.Data = DateTime.Now.ToString("HH:mm:ss.fff");

		// Store duration
    duration += 100;

    // Stop after 10 seconds
  	if (duration >= 10000)
		{
			// Exit when all fonts has been used
			timer.Stop();
			canvas.Exit();
		}
	}
}
