using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;

class TestCommunicationIndustrialInterface
{
	static List<int> inPortsInterface1 = new List<int>() { 
		101, 102, 103, 104, 105, 106, 107, 108,
	};

	static List<int> inPortsInterface2 = new List<int>() { 
		301, 302, 303, 304, 305, 306, 307, 308,
	};

	static List<int> outPortsInterface1 = new List<int>() { 
		201, 202, 203, 204, 
		221, 222, 223, 224, 225, 226, 227, 228,
	};
	
	static List<int> outPortsInterface2 = new List<int>() { 
		401, 402, 403, 404, 
		421, 422, 423, 424, 425, 426, 427, 428,
	};

	static int Main(string[] args)
    {
        Console.WriteLine("CommunicationIndustrialInterface");

		// Init Industrial Interface
		Communication.IndustrialInterface industrialInterface =
			new Communication.IndustrialInterface();
		
		// Try read input ports
		ReadPorts(industrialInterface, inPortsInterface1);
		ReadPorts(industrialInterface, inPortsInterface2);
		
		// Try write and read output ports
		ReadWritePorts(industrialInterface, outPortsInterface1);
		ReadWritePorts(industrialInterface, outPortsInterface2);
		
		Thread.Sleep(1000);
		
        // Cleanup Industrial Interface
        industrialInterface.Dispose();

        return 0;
    }

	private static void ReadPorts(Communication.IndustrialInterface 
																industrialInterface,
	                              List<int> portList)
	{
		bool readSignal;
		foreach (int inPort in portList)
		{
			Console.Write("Port {0}: ", inPort);
			try
			{
				readSignal = industrialInterface.GetPort(inPort);
				Console.Write("Read {0}", readSignal.ToString());
			}
			catch(GeneralException exception)
			{
				// Expected exception for ports not present
				Console.Write("Not present (GeneralException: {0})", 
				              exception.Message);
			}
			catch(Exception exception)
			{
				// Unexpected exception
				Console.Write("GeneralException: {0})", exception.Message);
			}
			Console.WriteLine("");
		}
	}

	private static void ReadWritePorts(Communication.IndustrialInterface 
																		 industrialInterface,
	                                   List<int> portList)
	{
		bool readSignal;
		bool writeSignal;
		foreach (int outPort in portList)
		{
			Console.Write("Port {0}: ", outPort);
			try
			{
				// Set port high (true)
				writeSignal = true;
				industrialInterface.SetPort(outPort, writeSignal);
				readSignal = industrialInterface.GetPort(outPort);
				Console.Write("Wrote {0}, Read {1}    ",
				              writeSignal, readSignal);
				
				// Set port low (false)
				writeSignal = false;
				industrialInterface.SetPort(outPort, writeSignal);
				readSignal = industrialInterface.GetPort(outPort);
				Console.Write("Wrote {0}, Read {1}    ",
				              writeSignal, readSignal);
			}
			catch(GeneralException exception)
			{
				// Expected exception for ports not present
				Console.Write("Not present (GeneralException: {0})", 
				              exception.Message);
			}
			catch(Exception exception)
			{
				// Unexpected exception
				Console.Write("GeneralException: {0})", exception.Message);
			}
			Console.WriteLine("");
		}
	}
}

