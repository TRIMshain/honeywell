using System;

class TestDrawingTextBox
{
	static int Main(string[] args)
	{
		Console.WriteLine("DrawingTextBox");
		
		// Init new PrintControl and Drawing
		PrintControl printControl = new PrintControl();
		Drawing drawing = new Drawing();
		
		// Render Hello World text
		drawing.Clear();

		Drawing.TextBox helloworld = new Drawing.TextBox(20, 20, "Univers", "Hello World", 600, 200, 5);
		drawing += helloworld;
		
		// Print label (1 copy)
		printControl.PrintFeed(drawing, 1);
		
		// Cleanup PrintControl and Drawing
		printControl.Dispose();
		drawing.Dispose();
		
		return 0;
	}
}

