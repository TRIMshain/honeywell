using System;
using System.IO;
using System.Threading;

class TestCommunicationUSBHost
{
    static int Main(string[] args)
    {
        Console.WriteLine("CommunicationUSBHost");

		// Get list of USB Host connected devices
		string[] usbPortNames = Communication.USBHost.GetPortNames();
		foreach(string usbPortName in usbPortNames)
		{
			Console.WriteLine("Found: " + usbPortName);
		}
		
		// Open the first USB host device and read any data sent
		Communication.USBHost usbHost = 
			new Communication.USBHost("/dev/ttyUSB0");
		
		usbHost.Open();
		
		if(usbHost.IsOpen)
		{
			Console.WriteLine("Opened /dev/ttyUSB0 ({0})",
			                  usbHost.HIDName);
		
			FileStream fileStream = usbHost.GetStream();
			
			try
			{
				int timeout = 0;
				int i;
			
				while(timeout < 10)
				{
					Console.WriteLine("Exiting in {0} secs", 10 - timeout);			
					Byte[] bytes = new Byte[256];
					
					if((i = fileStream.Read(bytes, 0, bytes.Length)) > 0)
					{
						string data = System.Text.Encoding.ASCII.GetString(bytes, 0, i);
						Console.WriteLine("read {0} bytes: {1}", data.Length, data);
						timeout = 0;
					}
					else 
					{
						Thread.Sleep(1000);
						timeout++;
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Exception reading /dev/ttyUSB0: {0}", ex.Message);
			}

			usbHost.Close();
		}
		
		// Wait a short while
		Thread.Sleep(1000);

		// Clean up 
		usbHost.Dispose();
		
        return 0;
    }
}
