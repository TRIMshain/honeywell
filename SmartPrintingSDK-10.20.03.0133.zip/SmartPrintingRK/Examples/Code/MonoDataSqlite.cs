using System.Data;
using System.IO;
using Mono.Data.Sqlite;

class TestMonoDataSqlite
{   
	static int Main(string[] args)
	{
		IDbConnection dbcon;
		string connectionString = @"URI=file:/tmp/sqlitetest.db";
		dbcon = (IDbConnection)new SqliteConnection(connectionString);
		dbcon.Open();
		IDbCommand dbcmd = dbcon.CreateCommand();
		int rv;
		
		// Drop table if already exists
		dbcmd.CommandText = "DROP TABLE IF EXISTS presidents;";
		rv = dbcmd.ExecuteNonQuery();
		
		// Create table
		dbcmd.CommandText = "CREATE TABLE presidents (" +
			"id INTEGER PRIMARY KEY AUTOINCREMENT," +
			"firstname VARCHAR(32)," +
			"lastname VARCHAR(32));";
		rv = dbcmd.ExecuteNonQuery();

		// Insert items in table
		dbcmd.CommandText = "INSERT INTO presidents(firstname,lastname) " +
			"VALUES ('Barack', 'Obama');";
		rv = dbcmd.ExecuteNonQuery();
		dbcmd.CommandText = "INSERT INTO presidents(firstname,lastname) " +
			"VALUES ('George', 'Bush');";
		rv = dbcmd.ExecuteNonQuery();
		
		// Retrieve all items in table in descending id order
		dbcmd.CommandText = "SELECT firstname, lastname, id " +
			"FROM presidents ORDER BY ID DESC;";
		IDataReader reader = dbcmd.ExecuteReader();
		while (reader.Read())
		{
			string FirstName = reader.GetString(0);
			string LastName = reader.GetString(1);
			string Id = reader.GetInt32(2).ToString();
			Console.WriteLine("Id: {0} Name: {1} {2}", Id, FirstName, LastName);
		}
		reader.Close();
		reader = null;
		
		// Trying invalid syntax
		try
		{
			dbcmd.CommandText = "DELETE * FROM presidents;";
			rv = dbcmd.ExecuteNonQuery();
		}
		catch (SqliteException ex)
		{
			Console.WriteLine("Got expected exception: {0}", ex.Message);
		}
		catch (Exception ex)
		{
			Console.WriteLine("Caught unexpected exception: {0}}" + ex.Message);
		}
		
		// Delete items from table
		dbcmd.CommandText = "DELETE FROM presidents;";
		rv = dbcmd.ExecuteNonQuery();
		
		// Drop table 
		dbcmd.CommandText = "DROP TABLE presidents;";
		rv = dbcmd.ExecuteNonQuery();
		
		// Delete database file
		File.Delete(@"/tmp/sqlitetest.db");
		
		dbcmd.Dispose();
		dbcmd = null;
		dbcon.Close();
		dbcon = null;
		
		
		return rv;
	}
}
