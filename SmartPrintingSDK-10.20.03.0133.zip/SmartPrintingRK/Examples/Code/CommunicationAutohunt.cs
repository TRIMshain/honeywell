using System;
using System.IO;
using System.Threading;

class TestCommunicationAutohunt
{
    static int Main(string[] args)
    {
        Console.WriteLine("CommunicationAutohunt");

		// Initialize Autohunt
		Communication.Autohunt autohunt = new Communication.Autohunt();
		
		// Add USB Host connected devices to autohunt
		string[] usbPortNames = Communication.USBHost.GetPortNames();
		foreach(string usbPortName in usbPortNames)
		{
			Communication.USBHost usbHost = 
				new Communication.USBHost(usbPortName);
			usbHost.Open();
			if(usbHost.IsOpen)
			{
				autohunt.AddStream(usbHost.GetStream());
				Console.WriteLine("Added: " + usbPortName);
			}
		}

		// Add Serial ports to autohunt
		string[] serialPortNames = Communication.SerialPort.GetPortNames();
		foreach(string serialPortName in serialPortNames)
		{
			Communication.SerialPort serialPort = 
				new Communication.SerialPort(serialPortName);
			serialPort.Open();
			serialPort.BaudRate = 115200;
			serialPort.Parity = System.IO.Ports.Parity.None;
			serialPort.StopBits = System.IO.Ports.StopBits.One;
			serialPort.DataBits = 8;
			serialPort.Handshake = System.IO.Ports.Handshake.None;
			autohunt.AddStream(serialPort.BaseStream);
			Console.WriteLine("Added: " + serialPortName);
		}
		
		try
		{
			int timeout = 0;
			int i;
			
			while(timeout < 10)
			{
				Console.WriteLine("Exiting in {0} secs", 10 - timeout);			
				Byte[] bytes = new Byte[256];

				if((i = autohunt.Read(bytes, 0, bytes.Length)) > 0)
				{
					string data = System.Text.Encoding.ASCII.GetString(bytes, 0, i);
					Console.WriteLine("echo {0} bytes: {1}", data.Length, data);
					autohunt.Write(bytes, 0, data.Length);
					timeout = 0;
				}
				else
				{
					Thread.Sleep(1000);
					timeout++;
				}
			}
		}
		catch (Exception ex)
		{
			Console.WriteLine("Exception: {0}", ex.Message);
		}
		
		// Wait a short while
		Thread.Sleep(1000);

		// Clean up 
		autohunt.Dispose();
		
        return 0;
    }
}
