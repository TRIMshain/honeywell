using System;
using System.IO;

class TestSecurity
{
		static int Main(string[] args)
		{
				Console.WriteLine("Security");

				// Init new security
				Security security = new Security();

				// Get current user
				string user;
				user = security.CurrentUser;
				Console.WriteLine("CurrentUser: {0}", user);

				// Set current user to admin
				security.SetUser("admin", "pass");
				user = security.CurrentUser;
				Console.WriteLine("CurrentUser: {0}", user);

				// Set current user to itadmin
				security.SetUser("itadmin", "pass");
				user = security.CurrentUser;
				Console.WriteLine("CurrentUser: {0}", user);

				// Set current user back to user
				security.SetUser("user", "");
				user = security.CurrentUser;
				Console.WriteLine("CurrentUser: {0}", user);

				return 0;
		}
}

