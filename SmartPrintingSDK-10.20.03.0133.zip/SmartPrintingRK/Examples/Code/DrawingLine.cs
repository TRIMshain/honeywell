using System;

class TestDrawingLine
{
	static int Main(string[] args)
	{
		Console.WriteLine("DrawingLine");
		
		// Init new PrintControl and Drawing
		PrintControl printControl = new PrintControl();
		Drawing drawing = new Drawing();
		
		// Perform tests
		Drawing.Line line1 = new Drawing.Line(100, 100, 700, 100, 2);
		drawing += line1;
		Drawing.Line line2 = new Drawing.Line(81, 100, 81, 700, 20);
		drawing += line2;
		Drawing.Line line3 = new Drawing.Line(196, 200, 596, 600, 4);
		drawing += line3;

		// Print label (1 copy)
		printControl.PrintFeed(drawing, 1);

		// Cleanup PrintControl and Drawing
		printControl.Dispose();
		drawing.Dispose();
		
		return 0;
	}
}
