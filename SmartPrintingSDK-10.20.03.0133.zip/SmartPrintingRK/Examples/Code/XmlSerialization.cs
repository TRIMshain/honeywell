using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Xml.Serialization;

class TestXmlSerialization
{
	static int Main(string[] args)
	{
		Console.WriteLine("XmlSerialization");
		
		// Init new PrintControl and Drawing
		PrintControl printControl = new PrintControl();
		Drawing drawing = new Drawing();

		// Create label layout
		CreateLabel(drawing);
		
		// Export XML serialization label
		ExportXml(drawing, "/tmp/label.xml");
		
		// Print original label
		printControl.PrintFeed(drawing, 1);

		// Clear drawing
		drawing.Clear();
		
		// Import XML serialization label
		ImportXml(drawing, "/tmp/label.xml");
		
		// Print imported label
		printControl.PrintFeed(drawing, 1);

		// Cleanup PrintControl and Drawing
		printControl.Dispose();
		drawing.Dispose();
		
		return 0;
	}

	private static void CreateLabel(Drawing drawing)
	{
		drawing.PartialRendering = true;
		drawing.Clear();
		drawing += new Drawing.Line(10, 810, 796, 810, 4);
		drawing += new Drawing.Line(10, 1013, 796, 1013, 4);
		drawing += new Drawing.Line(10, 607, 796, 607, 4);
		drawing += new Drawing.Line(10, 404, 796, 404, 4);
		drawing += new Drawing.Line(455, 609, 455, 406, 4);
		drawing += new Drawing.Line(455, 1015, 455, 812, 4);
		drawing += new Drawing.Line(338, 1193, 338, 1015, 4);
		Drawing.Text text1 = new Drawing.Text(23, 1184, "Swiss 721 BT");
		text1.Direction = 0;
		text1.CharacterEncoding = CharacterEncoding.Latin1;
		text1.Alignment = Drawing.Alignment.LeftTop;
		text1.Height = 8;
		text1.Slant = 0;
		text1.Data = "SHIP FROM:";
		drawing += text1;
		Drawing.Text text2 = new Drawing.Text(353, 1184, "Swiss 721 BT");
		text2.Alignment = Drawing.Alignment.LeftTop; 
		text2.Height = 8;
		text2.Data = "SHIP TO:";
		drawing += text2;
		Drawing.Text text3 = new Drawing.Text(23, 1145, "Swiss 721 BT");
		text3.Alignment = Drawing.Alignment.LeftTop;
		text3.Height = 10;
		text3.Data = "FromAddress1";
		drawing += text3;
		Drawing.Text text4 = new Drawing.Text(23, 1104, "Swiss 721 BT");
		text4.Alignment = Drawing.Alignment.LeftTop;
		text4.Height = 10;
		text4.Data = "FromAddress2";
		drawing += text4;
		Drawing.Text text5 = new Drawing.Text(23, 1064, "Swiss 721 BT");
		text5.Alignment = Drawing.Alignment.LeftTop;
		text5.Height = 10;
		text5.Data = "FromAddress3";
		drawing += text5;
		Drawing.Text text6 = new Drawing.Text(353, 1147, "Swiss 721 BT");
		text6.Alignment = Drawing.Alignment.LeftTop;
		text6.Height = 12;
		text6.Data = "ToAddress1";
		drawing += text6;
		Drawing.Text text7 = new Drawing.Text(353, 1104, "Swiss 721 BT");
		text7.Alignment = Drawing.Alignment.LeftTop;
		text7.Height = 12;
		text7.Data = "ToAddress2";
		drawing += text7;
		Drawing.Text text8 = new Drawing.Text(353, 1061, "Swiss 721 BT");
		text8.Alignment = Drawing.Alignment.LeftTop;
		text8.Height = 12;
		text8.Data = "ToAddress3";
		drawing += text8;
		Drawing.Barcode bar1 = new Drawing.Barcode(75, 924, "CODE128C");
		bar1.BarWidthWide = 2;
		bar1.WidthMagnification = 4;
		bar1.Height = 102;
		bar1.Data = "42072712";
		bar1.Alignment = Drawing.Alignment.LeftTop;
		drawing += bar1;
		Drawing.Text text9 = new Drawing.Text(131, 982, "Swiss 721 BT");
		text9.Alignment = Drawing.Alignment.LeftTop;
		text9.Height = 14;
		text9.Data = "(420) 72712";
		drawing += text9;
		Drawing.Text text10 = new Drawing.Text(20, 1012, "Swiss 721 BT");
		text10.Alignment = Drawing.Alignment.LeftTop;
		text10.Height = 8;
		text10.Data = "SHIP TO POSTAL CODE:";
		drawing += text10;
		Drawing.Text text11 = new Drawing.Text(467, 1012, "Swiss 721 BT");
		text11.Alignment = Drawing.Alignment.LeftTop;
		text11.Height = 8;
		text11.Data = "CARRIER:";
		drawing += text11;
		Drawing.Text text12 = new Drawing.Text(569, 809, "Swiss 721 BT");
		text12.Alignment = Drawing.Alignment.LeftTop;
		text12.Height = 8;
		text12.Data = "DC NUMBER";
		drawing += text12;
		Drawing.Text text13 = new Drawing.Text(467, 964, "Swiss 721 BT");
		text13.Alignment = Drawing.Alignment.LeftTop;
		text13.Height = 14;
		text13.Data = "PRO #:";
		drawing += text13;
		Drawing.Text text14 = new Drawing.Text(467, 904, "Swiss 721 BT");
		text14.Alignment = Drawing.Alignment.LeftTop;
		text14.Height = 14;
		text14.Data = "B/L #:";
		drawing += text14;
		Drawing.Text text15 = new Drawing.Text(45, 742, "Swiss 721 BT");
		text15.Alignment = Drawing.Alignment.LeftTop;
		text15.Height = 18;
		text15.Data = "PO    :0433124568";
		drawing += text15;
		Drawing.Text text16 = new Drawing.Text(42, 681, "Swiss 721 BT");
		text16.Alignment = Drawing.Alignment.LeftTop;
		text16.Height = 18;
		text16.Data = "WMIT:  001286123";
		drawing += text16;
		Drawing.Text text17 = new Drawing.Text(518, 796, "Swiss 721 BT");
		text17.Alignment = Drawing.Alignment.LeftTop;
		text17.Height = 36;
		text17.Data = "6004";
		drawing += text17;
		Drawing.Barcode bar2 = new Drawing.Barcode(104, 330, "CODE128C");
		bar2.BarWidthWide = 2;
		bar2.WidthMagnification = 4;
		bar2.Height = 305;
		bar2.Data = "00100280283000550596"; 
		bar2.Alignment = Drawing.Alignment.LeftTop;
		drawing += bar2;
		Drawing.Text text18 = new Drawing.Text(91, 403, "Swiss 721 BT");
		text18.Alignment = Drawing.Alignment.LeftTop;
		text18.Height = 18;
		text18.Data = "(00) 1 0028028 300055059 6";
		drawing += text18;
		Drawing.Barcode bar3 = new Drawing.Barcode(97, 554, "CODE128C");
		bar3.BarWidthWide = 2;
		bar3.WidthMagnification = 4;
		bar3.Height = 140;
		bar3.Data = "911528";
		bar3.Alignment = Drawing.Alignment.LeftTop;
		drawing += bar3;
		Drawing.Text text19 = new Drawing.Text(156, 607, "Swiss 721 BT");
		text19.Alignment = Drawing.Alignment.LeftTop;
		text19.Height = 12;
		text19.Data = "(91)  1528";
		drawing += text19;
		Drawing.Text text20 = new Drawing.Text(20, 606, "Swiss 721 BT");
		text20.Alignment = Drawing.Alignment.LeftTop;
		text20.Height = 8;
		text20.Data = "STORE:";
		drawing += text20;
		Drawing.Text text21 = new Drawing.Text(467, 606, "Swiss 721 BT");
		text21.Alignment = Drawing.Alignment.LeftTop;
		text21.Height = 8;
		text21.Data = "MARK FOR ADDRESS:";
		drawing += text21;
		Drawing.Text text22 = new Drawing.Text(467, 561, "Swiss 721 BT");
		text22.Alignment = Drawing.Alignment.LeftTop;
		text22.Height = 10;
		text22.Data = "Store 1528";
		drawing += text22;
		Drawing.Text text23 = new Drawing.Text(467, 521, "Swiss 721 BT");
		text23.Alignment = Drawing.Alignment.LeftTop;
		text23.Height = 10;
		text23.Data = "Street Address";
		drawing += text23;
		Drawing.Text text24 = new Drawing.Text(467, 480, "Swiss 721 BT");
		text24.Alignment = Drawing.Alignment.LeftTop;
		text24.Height = 10;
		text24.Data = "City, ST  Zip Code";
		drawing += text24;
	}
	
	private static void ExportXml(Drawing drawing, string filename)
	{
		// Serialize the label format (objects) to XML
		XmlSerializer xmlSerializer = 
			new XmlSerializer(typeof(List<Drawing.Base>));
		TextWriter textWriter = new StreamWriter(filename);
		xmlSerializer.Serialize(textWriter, drawing.DrawingObjects);
		textWriter.Close();
	}
		
	private static void ImportXml(Drawing drawing, string filename)
	{
		// Deserialize/import label format from XML
		XmlSerializer xmlDeserializer = 
			new XmlSerializer(typeof(List<Drawing.Base>));
		TextReader textReader = new StreamReader(filename);
		drawing.DrawingObjects = 
			(List<Drawing.Base>)xmlDeserializer.Deserialize(textReader);
		textReader.Close();			
	}
}
