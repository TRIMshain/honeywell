using System;

class TestGeneralException
{
	static int Main(string[] args)
	{
		Console.WriteLine("GeneralException");
		
		// GeneralException()
		try
		{
			throw new GeneralException();
		}
		catch (GeneralException ex)
		{
			Console.WriteLine("GeneralException Message: " + ex.Message);
			Console.WriteLine("GeneralException ErrorCode: " + ex.ErrorCode);
		}
		catch (Exception ex)
		{
			Console.WriteLine("Unexpected Exception: " + ex.Message);
		}
		
		// GeneralException(string)
		try
		{
			throw new GeneralException("Custom message");
		}
		catch (GeneralException ex)
		{
			Console.WriteLine("GeneralException: " + ex.Message);
		}
		catch (Exception ex)
		{
			Console.WriteLine("Unexpected Exception: " + ex.Message);
		}
		
		// GeneralException(string, Exception)
		try
		{
			throw new GeneralException("Custom message", 
																 new ApplicationException(
																 "Custom application exception"));
		}
		catch (GeneralException ex)
		{
			Console.WriteLine("GeneralException: " + ex.Message);
			Console.WriteLine("GeneralException inner: " + ex.InnerException.Message);
		}
		catch (Exception ex)
		{
			Console.WriteLine("Unexpected Exception: " + ex.Message);
		}
		
		return 0;
	}
}
