using System;
using System.Threading;

class TestUILED
{
	public static int Main(string[] args)
	{
		Console.WriteLine("UICanvasLED");

		UI ui = new UI();
		
		foreach (LEDId ledId in Enum.GetValues(typeof(LEDId)))
		{
			try
			{
				Console.Write("Led {0}: ", Enum.GetName(typeof(LEDId), ledId));
				UI.LED led = new UI.LED(ledId);
				Console.Write("Init ");

				led.State = LEDState.Blinking;
				Console.Write("Blinking ");
				Thread.Sleep(100);
				
				led.State = LEDState.Off;
				Console.Write("Off ");
				Thread.Sleep(100);

				led.State = LEDState.On;
				Console.Write("On "); 
				Thread.Sleep(100);

				led.Dispose();
			}
			catch(GeneralException exception)
			{
				// Expected exception for LEDs not present
				Console.Write("Not present (GeneralException: {0})", 
				              exception.Message);
			}
			catch(Exception exception)
			{
				// Unexpected exception
				Console.Write("GeneralException: {0})", exception.Message);
			}
			
			Console.WriteLine("...");
		}

		Thread.Sleep(1000);

		ui.Dispose();
		
		return 0;
	}
}
