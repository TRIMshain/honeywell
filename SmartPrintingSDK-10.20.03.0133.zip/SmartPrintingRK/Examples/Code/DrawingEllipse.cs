using System;

class TestDrawingEllipse
{
	static int Main(string[] args)
	{
		Console.WriteLine("DrawingEllipse");
		
		// Init new PrintControl and Drawing
		PrintControl printControl = new PrintControl();
		Drawing drawing = new Drawing();
		
		// Render ellipse
		Drawing.Ellipse ellipse = new Drawing.Ellipse(20, 20, 400, 400, 10);
		drawing += ellipse;

		// Print label (1 copy)
		printControl.PrintFeed(drawing, 1);

		// Cleanup PrintControl and Drawing
		printControl.Dispose();
		drawing.Dispose();
		
		return 0;
	}	
}
