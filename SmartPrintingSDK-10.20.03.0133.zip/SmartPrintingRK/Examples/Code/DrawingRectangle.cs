using System;

class TestDrawingRectangle
{
	static int Main(string[] args)
	{
		Console.WriteLine("DrawingRectangle");
		
		// Init new PrintControl and Drawing
		PrintControl printControl = new PrintControl();
		Drawing drawing = new Drawing();
		
		// Render rectangle
		Drawing.Rectangle rectangle = new Drawing.Rectangle(20, 20, 100, 100, 5);
		drawing += rectangle;

		// Print label (1 copy)
		printControl.PrintFeed(drawing, 1);

		// Cleanup PrintControl and Drawing
		printControl.Dispose();
		drawing.Dispose();
		
		return 0;
	}
}
