using System;
using System.Collections.Generic;
using System.Threading;

class TestStatus
{
	static int Main(string[] args)
	{
		Console.WriteLine("Status");
		
		// Init Status 
		Status status = new Status();
		
		// Check highest priority error/status
		State state = status.GetState();
		Console.WriteLine("State:  " + state.ToString());
		
		// Get all errors/states
		List<State> states = status.GetStates();
		foreach (State stateItem in states)
		{
			Console.WriteLine("States: " + stateItem.ToString());
		}
		
		// Set up event handler for status updates
		status.Updated += StatusHandler;
		
		// Instruct user to trigger status event
		Console.WriteLine("Please lift the printhead to trigger status update");
		for (int i = 5; i > 0; i--)
		{
			Console.WriteLine("{0} seconds until application continues...", i);
			Thread.Sleep(1000);
		}
		
		// Cleanup Status
		status.Dispose();
		
		return 0;
	}
	
	public static void StatusHandler(Object obj, Status.StatusEventArgs eventArgs)
	{
		Console.WriteLine("Recevied Status Update: " + eventArgs.State.ToString() +
		                  "   Active: " + eventArgs.Active.ToString());
	}
}
