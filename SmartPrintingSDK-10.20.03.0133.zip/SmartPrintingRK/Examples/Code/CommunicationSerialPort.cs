using System;
using System.IO;
using System.Threading;

class TestCommunicationSerialPort
{
    static int Main(string[] args)
    {
		Thread thread = new Thread(new ParameterizedThreadStart(SerialEcho));
			
        Console.WriteLine("CommunicationSerialPort");

		// Get list of serial ports
		string[] serialPortNames = Communication.SerialPort.GetPortNames();
		foreach(string serialPortName in serialPortNames)
		{
			Console.WriteLine("Found: " + serialPortName);
		}
		
		// Init serial port 0
		Communication.SerialPort serial0 = 
			new Communication.SerialPort("/dev/ttyS0");
		try
		{
			serial0.Open();
			serial0.BaudRate = 115200;
			serial0.Parity = System.IO.Ports.Parity.None;
			serial0.StopBits = System.IO.Ports.StopBits.One;
			serial0.DataBits = 8;
			serial0.Handshake = System.IO.Ports.Handshake.None;
		}
		catch (Exception ex)
		{
			Console.WriteLine("Exception initing serial0: {0}", ex.Message);
		}

		// Init serial port 1
		Communication.SerialPort serial1 = 
			new Communication.SerialPort("/dev/ttyS1");
		try
		{
			serial1.Open();
			serial1.BaudRate = 115200;
			serial1.Parity = System.IO.Ports.Parity.None;
			serial1.StopBits = System.IO.Ports.StopBits.One;
			serial1.DataBits = 8;
			serial1.Handshake = System.IO.Ports.Handshake.None;
		}
		catch (Exception ex)
		{
			Console.WriteLine("Exception initing serial1: {0}", ex.Message);
		}

		// Different functionality depending on number of serial ports
		if(serial0.IsOpen && serial1.IsOpen)
		{
			// Two (or more) serial ports, use automated comm test assuming
			// they are connected via null modem cable.
			string writeBuffer, readBuffer;
			Console.WriteLine("Two serial ports installed (serial0, serial1)");
			thread.Start(serial0);
			writeBuffer = "the quick brown fox jumps over the lazy dog";
			serial1.Write(writeBuffer);
			Console.WriteLine("Main: Wrote {0} bytes: {1}", 
			                  writeBuffer.Length, writeBuffer);
			Thread.Sleep(100);
			readBuffer = serial1.ReadExisting();
			Console.WriteLine("Main: Read  {0} bytes: {1}", 
			                  readBuffer.Length, readBuffer);
			thread.Join();
		}
		else if(serial0.IsOpen)
		{
			// One serial port, run echo service
			Console.WriteLine("One serial port installed (serial0)");
			thread.Start(serial0);
			thread.Join();
		}
		else if(serial1.IsOpen)
		{
			// One serial port, run echo service
			Console.WriteLine("One serial port installed (serial1)");
			thread.Start(serial1);
			thread.Join();
		}
		else
		{
			// No serial ports present, don't do anything
			Console.WriteLine("No serial ports installed");
		}
		
		Thread.Sleep(1000);
		
        // Cleanup Serial Ports
        serial0.Dispose();
        serial1.Dispose();

        return 0;
    }

	private static void SerialEcho(Object data)
	{
		int timeout = 0;
		Communication.SerialPort serial = (Communication.SerialPort)data;
		
		while(timeout < 5)
		{
			Console.WriteLine("Exiting in {0} secs", 5 - timeout);			
			if(serial.BytesToRead > 0)
			{
				string buffer = serial.ReadExisting();
				serial.Write(buffer);
				timeout = 0;
				Console.WriteLine("SerialEcho: Echoed {0} bytes", buffer.Length);
			}
			
			Thread.Sleep(1000);
			timeout++;
		}
	}
}

