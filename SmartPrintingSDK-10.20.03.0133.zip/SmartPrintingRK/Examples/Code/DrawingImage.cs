using System;
using System.Collections.Generic;

class TestDrawingImage
{
	static List<string> imageNames = new List<string>() { 
		"CHESS2X2.1",
		"CHESS4X4.1",
		"DIAMONDS.1",
		"GLOBE.1",
	};
	
	static int Main(string[] args)
	{
  	int x = 20;

		Console.WriteLine("DrawingImage");
		
		// Init new PrintControl and Drawing
		PrintControl printControl = new PrintControl();
		Drawing drawing = new Drawing();
		
		// Render images
		foreach (string image in imageNames)
		{
			drawing += new Drawing.Image(x, 20, "/system/printer/images/" + image);
			x += 100;
		}
		
		// Print label (1 copy)
		printControl.PrintFeed(drawing, 1);

		// Cleanup PrintControl and Drawing
		printControl.Dispose();
		drawing.Dispose();
		
		return 0;
	}
}
