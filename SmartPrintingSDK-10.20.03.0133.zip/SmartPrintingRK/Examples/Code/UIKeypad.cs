using System;

class TestUIKeypad
{
	static UI.Canvas canvas;
	static UI.Keypad keypad;
	static UI.Canvas.Text txt1;
	static UI.Canvas.Text txt2;
	static UI.Canvas.Text txt3;
	static UI.Canvas.Text txt4;
	static UI.Canvas.Text txt5;
	static int timeout = 10;
	
	static int Main(string[] args)
	{
		Console.WriteLine("UICanvasKeypad");

		// Init new UI canvas
		canvas = new UI.Canvas();
		
		// Set up some colors to use
		Color white = new Color(255, 255, 255, 255);
		Color black = new Color(0, 0, 0, 255);
		
		// Add UI black background
		UI.Canvas.Rectangle bg = new UI.Canvas.Rectangle(0, 0, canvas.Width, 
		                                                 canvas.Height, black);
		canvas += bg;
		
		// Add UI title text
		txt1 = new UI.Canvas.Text(20, 20, "TestUIKeypad", "Univers", 24, white);
		canvas += txt1;
		
		// Add UI user instructions text
		txt2 = new UI.Canvas.Text(20, 70, "Press the physical buttons", 
		                          "Univers", 18, white);
		canvas += txt2;
		txt3 = new UI.Canvas.Text(20, 90, "one at a time.",
		                          "Univers", 18, white);
		canvas += txt3;
		
		// Add UI timeout text
		txt4 = new UI.Canvas.Text(20, 140, "Exiting in " + timeout.ToString() + 
															" second(s)", "Univers", 18, white);
		canvas += txt4;
		
		// Add UI keycode text
		txt5 = new UI.Canvas.Text(20, 190, "Key code: ",
		                          "Univers", 18, white);
		canvas += txt5;
		
		// Update console
		Console.WriteLine("Exiting in " + timeout.ToString() + " second(s)");

		// Set up keypad event handler
		keypad = new UI.Keypad();
		keypad.KeyDown += new UI.Keypad.KeyEventHandler(KeyHandlerDown);
		keypad.KeyUp += new UI.Keypad.KeyEventHandler(KeyHandlerUp);

		// Set up timer event handler
		UI.Canvas.Timer timer = new UI.Canvas.Timer();
		timer.Interval = 1000;
		timer.Tick += new UI.Canvas.TimerEventHandler(TimerHandler);
		timer.Start();

		// Enter UI main loop
		canvas.Run();
		
		// Cleanup UI
		canvas.Dispose();
		keypad.Dispose();
		
		return 0;
	}
	
	public static void KeyHandlerDown(Object o, UI.Keypad.KeyEventArgs evArgs)
	{
		int keycode;

		keycode = evArgs.KeyChar;

		// Update UI
		txt5.Data = "Key code: " + keycode.ToString() + " Press";
		timeout = 10;
		txt4.Data = "Exiting in " + timeout.ToString() + " second(s)";

		// Output on console
		Console.WriteLine("Key code: " + keycode.ToString());
		Console.WriteLine("Exiting in " + timeout.ToString() + " second(s)");
	}

	public static void KeyHandlerUp(Object o, UI.Keypad.KeyEventArgs evArgs)
	{
		int keycode;

		keycode = evArgs.KeyChar;

		// Update UI
		txt5.Data = "Key code: " + keycode.ToString() + " Release";
		timeout = 10;
		txt4.Data = "Exiting in " + timeout.ToString() + " second(s)";

		// Output on console
		Console.WriteLine("Key code: " + keycode.ToString());
		Console.WriteLine("Exiting in " + timeout.ToString() + " second(s)");
	}
	
	public static void TimerHandler(Object obj, UI.Canvas.TimerEventArgs evArgs)
	{
		timeout--;
		if (timeout > 0)
		{
			// Update UI
			txt4.Data = "Exiting in " + timeout.ToString() + " second(s)";

			// Output on console
			Console.WriteLine("Exiting in " + timeout.ToString() + " second(s)");
		}
		else
		{
			UI.Canvas.Timer timer = (UI.Canvas.Timer) obj;
			timer.Stop();
			canvas.Exit();
		}
	}
}
