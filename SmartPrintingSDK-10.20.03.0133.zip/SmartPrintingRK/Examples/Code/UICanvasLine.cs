using System;
using System.Collections.Generic;

class TestUICanvasLine
{
	enum LCDState
	{
		Init,
		Horizontal,
		Vertical,
		Complete,
	}
	static UI.Canvas canvas;
	static UI.Canvas.Timer timer;
	static int i = 0;
	static List<Color> colors = new List<Color>()
	{
		new Color(255, 255, 255),
		new Color(255,   0,   0),
		new Color(  0, 255,   0),
		new Color(  0,   0, 255),
		new Color(  0, 255, 255),
		new Color(255, 255,   0),
		new Color(127, 127, 127),
		new Color(127,   0,   0),
		new Color(  0, 127,   0),
		new Color(  0,   0, 127),
	};
	static LCDState lcdState = LCDState.Init;
	
	static int Main(string[] args)
	{
		Console.WriteLine("UICanvasLine");
		
		// Init new UI canvas
		canvas = new UI.Canvas();
		
		// Set up some colors to use for welcome screen
		Color white = new Color(255, 255, 255, 255);
		Color black = new Color(0, 0, 0, 255);
		
		// Add UI black background
		UI.Canvas.Rectangle bg = new UI.Canvas.Rectangle(0, 0, canvas.Width,
		                                                 canvas.Height, black);
		canvas += bg;
		
		// Add UI title text
		UI.Canvas.Text titleText = new UI.Canvas.Text(5, (canvas.Height / 2) - 20,
		                                              "TestUICanvasLine", 
																									"Univers", 18, white);
		canvas += titleText;
		
		// Set up timer event handler
		timer = new UI.Canvas.Timer();
		timer.Interval = 1000;
		timer.Tick += new UI.Canvas.TimerEventHandler(UpdateScreen);
		timer.Start();
		
		// Enter UI main loop
		canvas.Run();
		
		// Cleanup UI
		canvas.Dispose();
		timer.Dispose();
		
		return 0;
	}
	
	public static void UpdateScreen(Object obj, UI.Canvas.TimerEventArgs evArgs)
	{
		switch(lcdState)
		{
			case LCDState.Init:
				lcdState = LCDState.Horizontal;
				break;
				
			case LCDState.Horizontal:
				canvas.Clear();
				for (i = 0; i < canvas.Height; i++)
				{
					UI.Canvas.Line line = new UI.Canvas.Line(0, i, canvas.Width, i, 
																									 colors[(i/2)%colors.Count]);
					canvas += line;
				}
				lcdState = LCDState.Vertical;
				break;
				
			case LCDState.Vertical:
				canvas.Clear();
				for (i = 0; i < canvas.Width; i++)
				{
					UI.Canvas.Line line = new UI.Canvas.Line(i, 0, i, canvas.Height, 
																									 colors[(i/2)%colors.Count]);
					canvas += line;
				}
				lcdState = LCDState.Complete;
				break;
				
			case LCDState.Complete:
				timer.Stop();
				canvas.Exit();
				break;
		}
	}
}

