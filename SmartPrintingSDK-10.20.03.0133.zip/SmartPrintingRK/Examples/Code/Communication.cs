using System;

class TestCommunication
{
    static int Main(string[] args)
    {
        Console.WriteLine("Communication");

        // Init new Commuication
        Communication communication = new Communication();

        // At this point the regular firmware, i.e. 'Fingerprint', is no 
        // longer controlling I/O ports of the printer. The regular firmware
        // regains control on the next statement when the C# application
        // releases control.

        // Cleanup Communication
        communication.Dispose();

        return 0;
    }
}
