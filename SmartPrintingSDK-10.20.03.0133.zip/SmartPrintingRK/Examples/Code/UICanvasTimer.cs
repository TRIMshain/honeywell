using System;

class TestUICanvasTimer
{
	static UI.Canvas canvas;
	static UI.Canvas.Timer timer2s;
	
  static int Main(string[] args)
  {
		Console.WriteLine("UICanvasTimer");
		
		// Init new UI canvas
		canvas = new UI.Canvas();

		// Set up 2 s timer event handler
		timer2s = new UI.Canvas.Timer();
		timer2s.Interval = 2000;
		timer2s.Tick += new UI.Canvas.TimerEventHandler(TimerHandler2s);
		timer2s.Start();
		
		// Enter UI main loop
		canvas.Run();
		
		// Cleanup UI
		canvas.Dispose();
		timer2s.Dispose();
		
		return 0;
	}
	
	public static void TimerHandler2s(Object obj, UI.Canvas.TimerEventArgs evArgs)
	{
    Console.WriteLine("TimerHandler2s");
		timer2s.Enabled = false;
		canvas.Exit();
	}
}
