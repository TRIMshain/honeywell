using System;
using System.IO;
using System.Threading;

class TestCommunicationBluetoothListener
{
    static int Main(string[] args)
    {
		int timeout = 0;
		int i;
		
        Console.WriteLine("CommunicationBluetoothListener");

		// Set up a Bluetooth listener
		Communication.BluetoothListener bluetoothListener
			= new Communication.BluetoothListener();
		
		while(timeout < 10)
		{
			Console.WriteLine("Waiting for connection. Exit in {0} secs",
			                  (10 - timeout));
			
			// Check if there are any pending connections
			if(bluetoothListener.Pending())
			{
				// Accept client
				Communication.BluetoothClient bluetoothClient = 
					bluetoothListener.AcceptBluetoothClient();
				
				try
				{
					// Get stream to communicate with client
					FileStream fileStream = bluetoothClient.GetStream();
					Console.WriteLine("Connected");
				
					// Read and echo back data as long as client is connected
					while(bluetoothClient.Connected)
					{
						Byte[] bytes = new Byte[256];
						if((i = fileStream.Read(bytes, 0, bytes.Length)) > 0)
						{
							string data = System.Text.Encoding.ASCII.GetString(bytes, 0, i);
							Console.WriteLine("echo {0} bytes: {1}", data.Length, data);
							fileStream.Flush();
							fileStream.Write(bytes, 0, i);
						}
						else 
						{
							Thread.Sleep(500);
						}
					}
					
					// Close stream
					fileStream.Close();
				}
				catch(Exception e)
				{
					Console.WriteLine("Exception: {0}", e.Message);
				}

				Console.WriteLine("Bluetooth client disconnected");
				
				// Close connection 
				bluetoothClient.Close();
				bluetoothClient.Dispose();
				timeout = 0;
			}
			else
			{
				Thread.Sleep(1000);
				timeout++;
			}
		}

		bluetoothListener.Dispose();
		
		return 0;
	}
}

