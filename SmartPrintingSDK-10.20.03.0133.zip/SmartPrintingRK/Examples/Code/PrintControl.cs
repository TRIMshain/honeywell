using System;
using System.Collections.Generic;
using System.Threading;

class TestPrintControl
{
	static int Main(string[] args)
	{
		Console.WriteLine("PrintControl");
		
		// Init new PrintControl and Drawing
		PrintControl printControl = new PrintControl();
		Drawing drawing = new Drawing();
		
		// Calibrate for media
		State result = AutoCalibrate(printControl, drawing);
		
		// Get min/max print speeds
		int min = GetMinPrintSpeed(printControl);
		int max = GetMaxPrintSpeed(printControl);
		
		// Set normal/default printspeed
		printControl.PrintSpeed = 100;
		
		// Output results on console
		Console.WriteLine("AutoCalibrate:       {0}", 
											result.ToString());
		Console.WriteLine("DetectionMode:       {0}", 
											printControl.DetectionMode.ToString());
		Console.WriteLine("PrintMethod:         {0}", 
											printControl.PrintMethod.ToString());
		Console.WriteLine("StartAdjust:         {0}", 
											printControl.StartAdjust.ToString());
		Console.WriteLine("StopAdjust:          {0}", 
											printControl.StopAdjust.ToString());
		Console.WriteLine("PrintheadResolution: {0}", 
											printControl.PrintheadResolution.ToString());
		Console.WriteLine("PrintheadWidth:      {0}", 
											printControl.PrintheadWidth.ToString());
		Console.WriteLine("PrintSpeed:          {0}", 
											printControl.PrintSpeed.ToString());
		Console.WriteLine("Min PrintSpeed:      {0}", min);
		Console.WriteLine("Max PrintSpeed:      {0}", max);
		
		if (result == State.NoError)
		{
			// Print out a label with the data 
			drawing += new Drawing.Text(20, 360, "Andale Mono", 
																	"AutoCalibrate:       " + result.ToString());
			drawing += new Drawing.Text(20, 320, "Andale Mono", 
																	"DetectionMode:       " + 
																	printControl.DetectionMode.ToString());
			drawing += new Drawing.Text(20, 280, "Andale Mono", 
																	"PrintMethod:         " + 
																	printControl.PrintMethod.ToString());
			drawing += new Drawing.Text(20, 240, "Andale Mono", 
																	"StartAdjust:         " + 
																	printControl.StartAdjust.ToString());
			drawing += new Drawing.Text(20, 200, "Andale Mono", 
																	"StopAdjust:          " + 
																	printControl.StopAdjust.ToString());
			drawing += new Drawing.Text(20, 160, "Andale Mono", 
																	"PrintheadResolution: " + 
																	printControl.PrintheadResolution.ToString());
			drawing += new Drawing.Text(20, 120, "Andale Mono", 
																	"PrintheadWidth:      " + 
																	printControl.PrintheadWidth.ToString());
			drawing += new Drawing.Text(20, 80,  "Andale Mono", 
																	"PrintSpeed:          " + 
																	printControl.PrintSpeed.ToString());
			drawing += new Drawing.Text(20, 40,  "Andale Mono", 
																	"Min PrintSpeed:      " + 
																	min.ToString());
			drawing += new Drawing.Text(20, 0,   "Andale Mono", 
																	"Max PrintSpeed:      " + 
																	max.ToString());
			result = printControl.PrintFeed(drawing, 1);
			
			// Form feed one label
			result = printControl.FormFeed();
			
			// Form feed 100 dots and then retract 100 dots
			result = printControl.FormFeed(100);
			result = printControl.FormFeed(-100);
			
			// Print out a test label
			printControl.PrintTestLabel(TestLabel.PrintInformation);
			
			// Print out instruction to user to tear off media
			drawing.Clear();
			drawing += new Drawing.Text(20, 200, "Andale Mono", " ");
			drawing += new Drawing.Text(20, 80, "Andale Mono", "Please tear off media");
			drawing += new Drawing.Text(20, 40, "Andale Mono", "Please tear off media");
			drawing += new Drawing.Text(20, 0, "Andale Mono", "Please tear off media");
			result = printControl.PrintFeed(drawing, 1);
			Thread.Sleep(1000);
		}
		
		if (printControl.GetLabelTaken() != LabelTaken.SensorNotInstalled)
		{
			int feedLen = 200;
			Console.WriteLine("Testing label taken sensor");
			printControl.CleanFeed(feedLen);
			while ((printControl.GetLabelTaken() == LabelTaken.LabelPresent) &&
			       (feedLen > 0))
			{
				printControl.CleanFeed(-10);
				feedLen -= 10;
			}
		}
		else
		{
			Console.WriteLine("Label taken sensor not installed");
		}
		
		// Cleanup PrintControl and Drawing
		printControl.Dispose();
		drawing.Dispose();
		
		return 0;
	}
	
	/// <summary>
	/// A naive auto calibration of media
	/// </summary>
	public static State AutoCalibrate(PrintControl printControl, Drawing drawing)
	{
		State result = State.NoError;
		
		// Set zero start and stop adjust
		printControl.StartAdjust = 0;
		printControl.StopAdjust = 0;
		
		// Set media length eight inces, media w. gaps and TT
		drawing.Height = printControl.PrintheadResolution * 8;
		printControl.DetectionMode = DetectionMode.MediaWithGaps;
		try
		{
			printControl.PrintMethod = PrintMethod.ThermalTransfer;
		}
		catch (GeneralException)
		{
			// Printers without ribbon motor cannot be configured for TT, 
			// so fall back on DT
			printControl.PrintMethod = PrintMethod.DirectThermal;
		}
		
		while (true)
		{
			result = printControl.TestFeed();
			
			if (result != State.NoError)
			{
				if (result == State.OutOfRibbon)
				{
					printControl.PrintMethod = PrintMethod.DirectThermal;
					printControl.DetectionMode = DetectionMode.MediaWithGaps;
				}
				else if (result == State.RibbonFitted)
				{
					printControl.PrintMethod = PrintMethod.ThermalTransfer;
					printControl.DetectionMode = DetectionMode.MediaWithGaps;
				}
				else if (printControl.DetectionMode == DetectionMode.MediaWithGaps)
				{
					printControl.DetectionMode = DetectionMode.BlackMark;
				}
				else if (printControl.DetectionMode == DetectionMode.BlackMark)
				{
					printControl.DetectionMode = DetectionMode.VariableLengthStrip;
				}
			}
			else
			{
				break;
			}
		}
		return result;
	}
	
	/// <summary>
	/// Get max print speed
	/// </summary>
	public static int GetMaxPrintSpeed(PrintControl printControl)
	{
		int max = 0;
		for (int i = 100; i <= 500; i++)
		{
			try
			{
				printControl.PrintSpeed = i;
			}
			catch (GeneralException)
			{
				max = i - 1;
				break;
			}
		}
		return max;
	}
	
	/// <summary>
	/// Get min print speed
	/// </summary>
	public static int GetMinPrintSpeed(PrintControl printControl)
	{
		int min = 0;
		for (int i = 100; i > 0; i--)
		{
			try
			{
				printControl.PrintSpeed = i;
			}
			catch (GeneralException)
			{
				min = i + 1;
				break;
			}
		}
		return min;
	}
}
