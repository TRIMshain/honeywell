using System;

class TestUICanvas
{
	static int Main(string[] args)
	{
		Console.WriteLine("UICanvas");
		
		// Init new UI canvas
		UI.Canvas canvas = new UI.Canvas();
		
		// Check and present capabilities
		if (canvas.HasDisplay)
		{
			if (canvas.HasTouch)
			{
				Console.WriteLine("UI has LCD Touch screen");
			}
			else
			{
				Console.WriteLine("UI has LCD");
			}
			
			Console.WriteLine("UI LCD width:  {0}", canvas.Width);
			Console.WriteLine("UI LCD height: {0}", canvas.Height);
		}
		else
		{
			Console.WriteLine("UI has LEDs");
		}
		
		// Cleanup UI
		canvas.Dispose();
		
		return 0;
	}
}
