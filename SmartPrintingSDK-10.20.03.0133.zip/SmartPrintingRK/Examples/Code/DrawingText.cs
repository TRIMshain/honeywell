using System;

class TestDrawingText
{
	static int Main(string[] args)
	{
		Console.WriteLine("DrawingText");
		
		// Init new PrintControl and Drawing
		PrintControl printControl = new PrintControl();
		Drawing drawing = new Drawing();
		
		// Render Hello World text
		drawing.Clear();
    Drawing.Text helloworld = new Drawing.Text(20, 20, "Univers", 
																							 "Hello World");
		drawing += helloworld;

		// Print label (1 copy)
		printControl.PrintFeed(drawing, 1);
		
		// Cleanup PrintControl and Drawing
		printControl.Dispose();
		drawing.Dispose();
		
		return 0;
	}
}

