using System;

class TestDrawingBarcode
{
	static int Main(string[] args)
	{
		Console.WriteLine("DrawingBarcode");
		
		// Init new PrintControl and Drawing
		PrintControl printControl = new PrintControl();
		Drawing drawing = new Drawing();
		
		// Render barcode
		Drawing.Barcode barc = new Drawing.Barcode(20, 20, "CODE39", "12345");
		barc.Height = 120;
		barc.Text.Enabled = true;
		barc.Text.FontName = "Univers";
		barc.BarWidthWide = 3;
		barc.BarWidthNarrow = 1;
		barc.WidthMagnification = 1;
		drawing += barc;
			
		// Print label (1 copy)
		printControl.PrintFeed(drawing, 1);

		// Cleanup PrintControl and Drawing
		printControl.Dispose();
		drawing.Dispose();
		
		return 0;
	}
}

