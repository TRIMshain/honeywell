using System;
using System.Collections.Generic;

class TestUICanvasImage
{
	static UI.Canvas canvas;
	static UI.Canvas.Timer timer;
	static UI.Canvas.Image moveableImage;
	static int timeout = 5;
	enum Key
	{
		Left   = 13,
		Right  = 14,
		Up     = 15,
		Down   = 16,
	}
	
	static int Main(string[] args)
	{
		Console.WriteLine("UICanvasImage");

		// Init new UI canvas
		canvas = new UI.Canvas();

		// Set up some color to use for text
		Color color = new Color(255, 0, 0, 255);

		// Add UI image background (using printer standard background)
		UI.Canvas.Image background = new UI.Canvas.Image(0, 0,
		                                                 "/system/home/user/apps/idle_background.png", canvas.Width, canvas.Height);
		canvas += background;

		// Add UI title text
		UI.Canvas.Text titleText = new UI.Canvas.Text(5, canvas.Height - 40,
		                                              "TestUICanvasImage", 
																									"Univers", 18, color);
		canvas += titleText;

		// Add UI help text
		UI.Canvas.Text helpText = new UI.Canvas.Text(5, canvas.Height - 20,
		                                             "Use arrows to move image", 
																								 "Univers", 14, color);
		canvas += helpText;
		
		// Add moveable image
		moveableImage = new UI.Canvas.Image(50, 50, 
												"/system/usr/share/ui/images/bar/bar_bluetooth.png");
		canvas += moveableImage;
		
		// Set up timer event handler
		timer = new UI.Canvas.Timer();
		timer.Interval = 1000;
		timer.Tick += new UI.Canvas.TimerEventHandler(UpdateTimeout);
		timer.Start();
		
		// Set up button handler
		UI.Keypad keypad = new UI.Keypad();
		keypad.KeyDown += new UI.Keypad.KeyEventHandler(KeyHandler);
		
		// Enter UI main loop
		canvas.Run();
		
		// Cleanup UI
		canvas.Dispose();
		timer.Dispose();
		
		return 0;
	}
	
	public static void UpdateTimeout(Object obj, UI.Canvas.TimerEventArgs evArgs)
	{
		timeout--;
		
		if (timeout == 0)
		{
			timer.Stop();
			canvas.Exit();
		}
	}
	
	public static void KeyHandler(Object o, UI.Keypad.KeyEventArgs eventArgs)
	{
		timeout = 3;
		
		switch (eventArgs.KeyChar)
		{
			case (char)Key.Left:
				moveableImage.Point = 
						new Point(moveableImage.Point.X - 5, moveableImage.Point.Y);
				break;
				
			case (char)Key.Right:
				moveableImage.Point = 
						new Point(moveableImage.Point.X + 5, moveableImage.Point.Y);
				break;
				
			case (char)Key.Up:
				moveableImage.Point = 
						new Point(moveableImage.Point.X, moveableImage.Point.Y - 5);
				break;
				
			case (char)Key.Down:
				moveableImage.Point = 
						new Point(moveableImage.Point.X, moveableImage.Point.Y + 5);
				break;
		}
	}
}
