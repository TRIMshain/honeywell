using System;
using System.IO;
using System.Threading;

class TestCommunicationUSBDevice
{
    static int Main(string[] args)
    {
        Console.WriteLine("CommunicationUSBDevice");

        //Get list of USB device port
        string[] usbDevicePortNames = Communication.USBDevice.GetPortNames();
        foreach(string usbDevicePortName in usbDevicePortNames)
        {
            Console.WriteLine("Found: " + usbDevicePortName);
        }

        // Open the first USB device port and read any data sent
        Communication.USBDevice usbDevice = new Communication.USBDevice("/dev/ttyUSBD0");

        usbDevice.Open();

        if(usbDevice.IsOpen)
        {
            Console.WriteLine("Opened /dev/ttyUSBD0.");

            FileStream fileStream = usbDevice.GetStream();

            try
            {
                int timeout = 0;
                int i;

                while(timeout < 15)
                {
                    Console.WriteLine("Exiting in {0} secs", 15 - timeout);			
                    Byte[] bytes = new Byte[1024];

                    if ((i = fileStream.Read(bytes, 0, bytes.Length)) > 0)
                    {
                        string data = System.Text.Encoding.ASCII.GetString(bytes, 0, i);
                        Console.WriteLine("read {0} bytes: {1}", data.Length, data);
                        timeout = 0;
                    }
                    else 
                    {
                        Thread.Sleep(1000);
                        timeout++;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception reading /dev/ttyUSBD0: {0}", ex.Message);
            }

            usbDevice.Close();
        }

        // Wait a short while
        Thread.Sleep(1000);

        // Clean up 
        usbDevice.Dispose();

        return 0;
    }
}
