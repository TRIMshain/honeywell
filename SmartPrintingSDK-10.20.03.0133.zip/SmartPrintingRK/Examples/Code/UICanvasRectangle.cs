using System;
using System.Collections.Generic;

class TestUICanvasRectangle
{
	static UI.Canvas canvas;
	static UI.Canvas.Timer timer;
	static int timerCount = 0;
	static List<Color> colors = new List<Color>()
	{
		new Color(255, 255, 255),
		new Color(255,   0,   0),
		new Color(  0, 255,   0),
		new Color(  0,   0, 255),
		new Color(  0, 255, 255),
		new Color(255, 255,   0),
		new Color(127, 127, 127),
		new Color(127,   0,   0),
		new Color(  0, 127,   0),
		new Color(  0,   0, 127),
	};
	
	static int Main(string[] args)
	{
		Console.WriteLine("UICanvasRectangle");
		
		// Init new UI canvas
		canvas = new UI.Canvas();
		
		// Set up some colors to use for welcome screen
		Color white = new Color(255, 255, 255, 255);
		Color black = new Color(0, 0, 0, 255);
		
		// Add UI black background
		UI.Canvas.Rectangle bg = new UI.Canvas.Rectangle(0, 0, canvas.Width,
		                                                 canvas.Height, black);
		canvas += bg;
		
		// Add UI title text
		UI.Canvas.Text titleText = new UI.Canvas.Text(5, (canvas.Height / 2) - 20, 
		                                              "TestUICanvasRectangle", 
																									"Univers", 18, white);
		canvas += titleText;
		
		// Set up timer event handler
		timer = new UI.Canvas.Timer();
		timer.Interval = 500;
		timer.Tick += new UI.Canvas.TimerEventHandler(UpdateScreen);
		timer.Start();
		
		// Enter UI main loop
		canvas.Run();
		
		// Cleanup UI
		canvas.Dispose();
		timer.Dispose();
		
		return 0;
	}
	
	public static void UpdateScreen(Object obj, UI.Canvas.TimerEventArgs evArgs)
	{
		timerCount++;
		
		if (timerCount == 1)
		{
			// At first event, display four rectangles on screen
			UI.Canvas.Rectangle rec1 = new UI.Canvas.Rectangle(0, 
																												 0, 
																												 canvas.Width / 2, 
																												 canvas.Height / 2, 
																												 colors[0]);
			canvas += rec1;

			UI.Canvas.Rectangle rec2 = new UI.Canvas.Rectangle(canvas.Width / 2, 
																												 0, 
																												 canvas.Width / 2, 
																												 canvas.Height / 2, 
																												 colors[1]);
			canvas += rec2;

			UI.Canvas.Rectangle rec3 = new UI.Canvas.Rectangle(0, 
																												 canvas.Height / 2, 
																												 canvas.Width / 2, 
																												 canvas.Height / 2, 
																												 colors[2]);
			canvas += rec3;

			UI.Canvas.Rectangle rec4 = new UI.Canvas.Rectangle(canvas.Width / 2, 
																												 canvas.Height / 2, 
																												 canvas.Width / 2, 
																												 canvas.Height / 2, 
																												 colors[3]);
			canvas += rec4;
		}
		
		if (timerCount == 2)
		{
      // At second event, stop timer and exit UI main loop
			timer.Stop();
			canvas.Exit();
		}
	}
}
