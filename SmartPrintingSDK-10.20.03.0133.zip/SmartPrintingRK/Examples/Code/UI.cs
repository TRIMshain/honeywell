using System;

class TestUI
{
    static int Main(string[] args)
    {
        Console.WriteLine("UI");

        // Init new UI
        UI ui = new UI();

        // Cleanup UI
        ui.Dispose();

        return 0;
    }

}
